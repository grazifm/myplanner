package com.myplanner.myplanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyplannerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyplannerApplication.class, args);
	}

}
