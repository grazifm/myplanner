package com.myplanner.myplanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyplannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
